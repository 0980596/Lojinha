<footer>

    <p>© 2025 - Todos os direitos reservados.</p>
    
</footer>